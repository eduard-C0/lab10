export class Pet {
  id: number | undefined;
  name: string | undefined;
  species: string | undefined;
  sellingPrice: number | undefined;
}
