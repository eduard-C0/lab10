import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-new',
  templateUrl: './food-new.component.html',
  styleUrls: ['./food-new.component.css']
})
export class FoodNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
