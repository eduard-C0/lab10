export class Food {
  id: number | undefined;
  name: string | undefined;
  species: string | undefined;
  description: string | undefined;
  price: number | undefined;
}
