export class Toy {
   id :number | undefined;
   name: string | undefined;
   species: string | undefined;
   material: string | undefined;
   price: number | undefined;
  constructor(    ) {}
}
