import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toy-new',
  templateUrl: './toy-new.component.html',
  styleUrls: ['./toy-new.component.css']
})
export class ToyNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
