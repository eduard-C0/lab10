export class Person {
  id: number | undefined;
  name: string | undefined;
  budget: number | undefined;
}
