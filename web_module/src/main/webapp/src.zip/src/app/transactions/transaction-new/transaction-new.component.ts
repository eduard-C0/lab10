import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaction-new',
  templateUrl: './transaction-new.component.html',
  styleUrls: ['./transaction-new.component.css']
})
export class TransactionNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
