export class Transaction {
  id: number | undefined;
  pet: number | undefined;
  person: number | undefined;
}
